Family=information_ablation; shard=4/48; wave=0/1; reps=100; smoke=False
