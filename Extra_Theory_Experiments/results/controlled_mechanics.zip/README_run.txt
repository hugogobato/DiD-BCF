Controlled special-case mechanics diagnostic; not a theorem proof.
reps=100, draws=300, units=200, K=2
