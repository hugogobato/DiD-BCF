Family=information_ablation; shard=21/48; wave=0/1; reps=100; smoke=False
