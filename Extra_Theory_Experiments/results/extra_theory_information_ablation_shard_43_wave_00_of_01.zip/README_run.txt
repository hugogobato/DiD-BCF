Family=information_ablation; shard=43/48; wave=0/1; reps=100; smoke=False
