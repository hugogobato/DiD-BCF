Family=information_ablation; shard=0/1; wave=0/1; reps=1; smoke=False
