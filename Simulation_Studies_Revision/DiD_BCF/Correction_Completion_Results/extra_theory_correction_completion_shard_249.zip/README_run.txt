Family=correction_completion; shard=249/384; wave=0/1; reps=None; smoke=False
