Family=correction_completion; shard=66/384; wave=0/1; reps=None; smoke=False
